def snippetsInit():
  pass

def snippetsFormatPlaceHolder(word):
  return ''

def snippetsAddSnippet(fullname, word, abbr):
  return abbr

def snippetsTrigger():
  pass

def snippetsReset():
  pass

# vim: set ts=2 sts=2 sw=2 expandtab :
